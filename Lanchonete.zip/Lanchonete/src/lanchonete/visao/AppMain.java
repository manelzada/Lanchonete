package lanchonete.visao;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.NotSerializableException;
import java.util.ArrayList;
import java.util.Random;
import lanchonete.controle.ControleUsuario;
import lanchonete.controle.ControleProduto;
import java.util.Scanner;
import lanchonete.controle.ControleGerente;
import lanchonete.controle.ControlePedido;
import lanchonete.modelo.Gerente;
import lanchonete.modelo.Pedido;
import lanchonete.modelo.Produto;

public class AppMain {
    public static void main(String[]args) throws IOException, FileNotFoundException, ClassNotFoundException{
       
        Scanner tec = new Scanner(System.in);
        int opPag=3;
        while(opPag!=0){
 
        System.out.println("escolha a sua página");
        System.out.println("[1] Página do usuário cliente");
        System.out.println("[2] Página do gerente ");
        System.out.println("[0] sair ");
        opPag = tec.nextInt();
        switch(opPag){
            case 1:
                pagUsuario();
                break;
            case 2:
                pagGerente();
                break;
        }
        }
    }

    public static String menu(){
        return "[1] Já sou cadastrado"+
                "\n[2] Realizar cadastro"+
                "\n[0] sair";
    }
    public static void pagUsuario() throws IOException, FileNotFoundException, ClassNotFoundException {
        String nome, nickName, email, telefone, cpf, senha, sexo;
        ControleUsuario objControleUsuario = new ControleUsuario();
        Scanner tec = new Scanner(System.in);
        Scanner tecStr = new Scanner(System.in);
        int op =3;
        System.out.println("escolha uma das opções");
        System.out.println(menu());
        op = tec.nextInt();
        
        while(op !=0){
       

            try{
               
                switch(op){
                 //login
                    case 1:{
                         
                         System.out.println("Digite o seu nickName");
                         nickName = tecStr.nextLine();
                         tec.nextLine();
                         System.out.println("Digite a sua senha");
                         senha = tec.nextLine();
                         boolean retorno = objControleUsuario.loginUsuario(nickName, senha);
                             if(retorno == false){
                                 System.out.println("senha incorreta");
                                 break;
                             }else{
                                 centralLanchonete(nickName);
                             }   
                         break;
                    }    
                     //fazer cadastro
                    case 2:{
                         System.out.println("Digtite o seu nome");
                         tec.nextLine();
                         nome = tec.nextLine();
                         System.out.println("Digite o seu cpf");
                         cpf = tec.nextLine();
                         System.out.println("Digite o seu email");
                         email = tec.nextLine();
                         System.out.println("Digite o seu nickName");
                         nickName = tec.nextLine();
                         System.out.println("Digite o seu telefone");
                         telefone = tec.nextLine();
                         System.out.println("Digite o seu sexo: ");
                         sexo = tec.nextLine();
                         System.out.println("crie a sua senha");
                         senha = tec.nextLine();
                         objControleUsuario.cadastrarUsuario(nome, nickName, email, telefone, cpf, senha, sexo);
                         System.out.println("Usuário cadastrado com sucesso");
                        break;
                    }
                }
            }catch(FileNotFoundException e){
                System.out.println(e.getMessage());
            }catch(java.io. NotSerializableException e){
                System.out.println(e.getMessage());
            }

            System.out.println("escolha uma das opções");
            System.out.println(menu());
            op = tec.nextInt();
        }
        
    }
    public static void pagGerente() throws IOException, FileNotFoundException, ClassNotFoundException{
        Scanner tec = new Scanner(System.in);
        ControleGerente objControleGerente = new ControleGerente();
        //objControleGerente.cadastrarGerente("Abel","(77)98818-5833","123","cisgenero","66770055-98");
        String nome, senha;
        System.out.println("Digite o seu nome ");
        nome = tec.nextLine();
        System.out.println("Digite a sua senha");
        senha = tec.nextLine();
        try{
            
        
        boolean retorno = objControleGerente.loginGerente(nome, senha);
                             if(retorno == false){
                                 System.out.println("senha incorreta");
                             }else{
                                 System.out.println("Login efetuado com sucesso");
                                 centralLanchoneteAdmin();
                             }
        }catch(NullPointerException e){
            System.out.println(" Login ou senha incorreta !!");
            
        }
        
    }
    public static void centralLanchonete(String nickName) throws IOException, FileNotFoundException, ClassNotFoundException{
        int op2 = 3 ;
        Scanner tectec = new Scanner(System.in);
        ArrayList <Produto> listPedido = new ArrayList<>();
        Produto objProduto = new Produto();
        ControlePedido objControlePedido = new ControlePedido();
        ControleUsuario objControleUsuario = new ControleUsuario();
        Random random = new Random();
        ControleProduto objControleProduto = new ControleProduto();
        try{
            do{
                System.out.println( objControleProduto.listarCardapio());
                System.out.println("Digite o número do seu lanche");
                int idPedido =  tectec.nextInt();
                 objProduto = objControleProduto.pesquisarProduto(idPedido);
                 listPedido.add(objProduto);
                    System.out.println("Deseja adicionar outro lanche ?");
                    System.out.println("[1] sim");
                    System.out.println("[0] não");
                    op2 = tectec.nextInt();
                }while(op2!=0);
            int codigo = random.nextInt(100);

            String usuario =  objControleUsuario.pesquisarUsuario(nickName);
            Pedido cadastroPedido =  objControlePedido.cadastrarPedido(listPedido, codigo, usuario);
            System.out.println(cadastroPedido.imprimirPedido(cadastroPedido));
        }catch(IOException | ClassNotFoundException e){
            System.out.println("erro! "+e.getMessage());
        }
    }
   //Identificador de produto
  
   public static void centralLanchoneteAdmin() throws IOException, FileNotFoundException, ClassNotFoundException{
       
        Scanner tec = new Scanner(System.in);
        ControleProduto objControleProduto = new ControleProduto();
        ControleGerente objControleGerente = new ControleGerente();
        Gerente objGerente = new Gerente();
        
        
        Random random = new Random();
        int op=10, id;
        String nomeProd, descricao, nomeGerente, telefone, senha, sexo, cpf;
        double valor;
        
        while(op!=0){
        System.out.println("[1] adicionar um produto");
        System.out.println("[2] adicionar Gerente");
        System.out.println("[3] listar produtos");
        System.out.println("[4] Remover produto");
        System.out.println("[0] sair");
        op = tec.nextInt();
            switch(op){
                case 1:{//add produto
                    tec.nextLine();
                    System.out.println("Digite o nome do produto");
                    nomeProd = tec.nextLine();
                    System.out.println("Digite o valor");
                    valor = tec.nextDouble();
                    tec.nextLine();
                    System.out.println("Digite a descrição do produto");
                    descricao = tec.nextLine();
                    objControleProduto.cadastrarProduto(nomeProd, valor, descricao);
                    break;
                }
                case 2:{//add gerente
                    tec.nextLine();
                    System.out.println("Digite o nome do Gerente");
                    nomeGerente = tec.nextLine();
                    System.out.println("Digite o seu telefone");
                    telefone = tec.nextLine();
                    System.out.println("Digite o sexo");
                    sexo = tec.nextLine();
                    System.out.println("Digite o seu cpf");
                    cpf = tec.nextLine();
                    System.out.println("Digite a sua senha");
                    senha = tec.nextLine();
                    objControleGerente.cadastrarGerente(nomeGerente, telefone,senha,sexo,cpf);
                    break;}
                case 3://listar produtos
                    System.out.println( objControleProduto.listarCardapio());
                    break;
                case 4:{//remover produto
                    System.out.println( objControleProduto.listarCardapio());
                    System.out.println("Digite o código do produto para remover");
                    id = tec.nextInt();
                    objControleProduto.removerGerente(id);
                    System.out.println("Produto removido com sucesso");
                }
            }
        }
       
    } 
}
