
package lanchonete.dados;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import lanchonete.modelo.Usuario;


public class UsuarioDados implements Serializable{

    
    public void cadastrarUsuarioD(Usuario objUsuario){
    ArrayList<Usuario> listUsuario = new ArrayList<>();
        try{
            listUsuario = listarUsuarios();
        }catch(FileNotFoundException e){
            File arquivo = new File("usuario.ser");
           try{     
            arquivo.createNewFile(); 
           }catch(IOException x){ }
        }catch(ClassNotFoundException | IOException e){
            e.printStackTrace();
        }
        try{
            listUsuario.add(objUsuario);
            System.out.println("parte 1");
            File endereco = new File("usuario.ser");
            FileOutputStream fluxo = new FileOutputStream(endereco);
            ObjectOutputStream oos = new ObjectOutputStream(fluxo);
            System.out.println("parte 2");
           oos.writeObject(listUsuario);
           oos.flush();
           fluxo.flush();
           oos.close();
           fluxo.close();
           System.out.println("parte 3");
           
       }catch(IOException e){
           e.printStackTrace();
       }
    }
     public ArrayList<Usuario> listarUsuarios() throws FileNotFoundException, IOException, ClassNotFoundException{
    ArrayList <Usuario> listUsuario;
    File endereco = new File ("usuario.ser");
    FileInputStream fluxo = new FileInputStream(endereco);
    ObjectInputStream lerObj = new ObjectInputStream(fluxo);
    listUsuario = (ArrayList<Usuario>) lerObj.readObject();
    
    return listUsuario;
  }
    
    public Usuario pesquisaUsuario(String nickName) throws IOException, FileNotFoundException, ClassNotFoundException{
        Usuario objUsuario = new Usuario();
        ArrayList <Usuario> listUsuario = listarUsuarios();
        for(int i = 0; i<listUsuario.size(); i++){
            if(listUsuario.get(i).getNickName().equals(nickName)){
                objUsuario = listUsuario.get(i);
            }
        }
        return objUsuario;
    }
    
    public void removerUsuario(String cod) throws FileNotFoundException, IOException, ClassNotFoundException{
        ArrayList <Usuario> listUsuario = listarUsuarios();
        for(int i = 0; i<listUsuario.size();i++){
            if(listUsuario.get(i).getCpf() == cod){
                listUsuario.remove(listUsuario.get(i));
                break;
            }
        }
        File arquivo = new File("usuario.ser");
        FileOutputStream  fluxo = new FileOutputStream(arquivo);
        try(ObjectOutputStream gravarObj = new ObjectOutputStream(fluxo)){
            gravarObj.writeObject(listUsuario);
   } 
  }
    
    
}