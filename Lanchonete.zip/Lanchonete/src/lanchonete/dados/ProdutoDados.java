
package lanchonete.dados;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import lanchonete.modelo.Produto;


public class ProdutoDados implements Serializable{

    Produto objProduto = new Produto();
    public void cadastrarProduto(Produto objProduto){
    ArrayList<Produto> listProduto = new ArrayList<>();
        try{
            listProduto = listarProduto();
        }catch(FileNotFoundException e){
            File arquivo = new File("produto.ser");
           try{     
            arquivo.createNewFile(); 
           }catch(IOException x){ }
        }catch(ClassNotFoundException | IOException e){
            e.printStackTrace();
        }
        try{
            listProduto.add(objProduto);
            File endereco = new File("produto.ser");
            FileOutputStream fluxo = new FileOutputStream(endereco);
            ObjectOutputStream oos = new ObjectOutputStream(fluxo);
           oos.writeObject(listProduto);
           oos.flush();
           fluxo.flush();
           oos.close();
           fluxo.close();
          
       }catch(IOException e){
           e.printStackTrace();
       }
    }
    
     public ArrayList<Produto> listarProduto() throws FileNotFoundException, IOException, ClassNotFoundException{
    ArrayList <Produto> listProduto;
    File endereco = new File ("produto.ser");
    FileInputStream fluxo = new FileInputStream(endereco);
    ObjectInputStream lerObj = new ObjectInputStream(fluxo);
    listProduto = (ArrayList<Produto>) lerObj.readObject();
    
    return listProduto;
  }
    
    public Produto pesquisaProduto(int id) throws IOException, FileNotFoundException, ClassNotFoundException{
        ArrayList <Produto> listProduto = listarProduto();
        for(int i = 0; i<listProduto.size(); i++){
            if(listProduto.get(i).getId() == id){
                objProduto = listProduto.get(i);
            }
        }
        return objProduto;
    }
    
    public void removerProduto(Produto p) throws FileNotFoundException, IOException, ClassNotFoundException{
        ArrayList <Produto> listProduto = listarProduto();
        for(int i = 0; i<listProduto.size();i++){
            if(listProduto.get(i).getId() == p.getId()){
                listProduto.remove(listProduto.get(i));
                break;
            }
        }
        File arquivo = new File("produto.ser");
        FileOutputStream  fluxo = new FileOutputStream(arquivo);
        try(ObjectOutputStream gravarObj = new ObjectOutputStream(fluxo)){
            gravarObj.writeObject(listProduto);
   } 
  }
}
