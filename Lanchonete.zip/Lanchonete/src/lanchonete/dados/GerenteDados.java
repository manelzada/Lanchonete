package lanchonete.dados;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import lanchonete.modelo.Gerente;

public class GerenteDados implements Serializable {

    /*public void cadastrarGerenteD(Gerente objGerente){
    ArrayList<Gerente> listGerente = new ArrayList<>();
        try{
            listGerente = listarGerentes();
        }catch(FileNotFoundException e){
            File arquivo = new File("gerente.ser");
           try{     
            arquivo.createNewFile(); 
           }catch(IOException x){ }
        }catch(ClassNotFoundException | IOException e){
            e.printStackTrace();
        }
        try{
            listGerente.add(objGerente);
            File endereco = new File("gerente.ser");
            FileOutputStream fluxo = new FileOutputStream(endereco);
            ObjectOutputStream oos = new ObjectOutputStream(fluxo);
           oos.writeObject(listGerente);
           oos.flush();
           fluxo.flush();
           oos.close();
           fluxo.close();
       }catch(IOException e){
           e.printStackTrace();
       }
    }
    public void cadastrarGerenteD(Gerente objGerente) throws FileNotFoundException, IOException, ClassNotFoundException{
        ArrayList<Gerente> listGerente = new ArrayList<>();
        File endereco = new File("gerente.ser");
        if(endereco.exists()){
            listGerente = listarGerentes();
        }
        listGerente.add(objGerente);
        FileOutputStream fluxo = new FileOutputStream(endereco);
        try(ObjectOutputStream gravarObj = new ObjectOutputStream(fluxo)){
            gravarObj.writeObject(listGerente);
        }
    }
     */
    public void cadastrarGerente(Gerente objGerente){
       
    ArrayList<Gerente> listGerente = new ArrayList<>();
        try{
            listGerente = listarGerente();
        }catch(FileNotFoundException e){
            File arquivo = new File("gerente2.ser");
           try{     
            arquivo.createNewFile(); 
           }catch(IOException x){ }
        }catch(ClassNotFoundException | IOException e){
            e.printStackTrace();
        }
        try{
            listGerente.add(objGerente);
            
            File endereco = new File("gerente2.ser");
            FileOutputStream fluxo = new FileOutputStream(endereco);
            ObjectOutputStream oos = new ObjectOutputStream(fluxo);
            System.out.println("parte 2");
           oos.writeObject(listGerente);
           oos.flush();
           fluxo.flush();
           oos.close();
           fluxo.close();
           System.out.println("parte 3");
           
       }catch(IOException e){
           e.printStackTrace();
       }
    }
    public ArrayList<Gerente> listarGerente() throws FileNotFoundException, IOException, ClassNotFoundException {
        ArrayList<Gerente> listGerente;
        File endereco = new File("gerente2.ser");
        FileInputStream fluxo = new FileInputStream(endereco);
        ObjectInputStream lerObj = new ObjectInputStream(fluxo);
        listGerente = (ArrayList<Gerente>) lerObj.readObject();

        return listGerente;
    }

    /*
    public Gerente pesquisaGerente(String cod) throws IOException, FileNotFoundException, ClassNotFoundException {
        Gerente objGerente = new Gerente();
        ArrayList<Gerente> listGerente = listarGerente();
        for (int i = 0; i < listGerente.size(); i++) {
            if (listGerente.get(i).getCpf().equals(cod)) {
                objGerente = listGerente.get(i);
            }
        }
        return objGerente;
    }
    */

    public void removerGerente(Gerente g) throws FileNotFoundException, IOException, ClassNotFoundException {
        ArrayList<Gerente> listGerente = listarGerente();
        for (int i = 0; i < listGerente.size(); i++) {
            if (listGerente.get(i).getNome().equals(g.getNome())) {
                listGerente.remove(listGerente.get(i));
                break;
            }
        }
        File arquivo = new File("gerente2.ser");
        FileOutputStream fluxo = new FileOutputStream(arquivo);
        try (ObjectOutputStream gravarObj = new ObjectOutputStream(fluxo)) {
            gravarObj.writeObject(listGerente);
        }
    }
}
