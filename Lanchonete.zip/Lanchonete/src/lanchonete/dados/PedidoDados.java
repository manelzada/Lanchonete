
package lanchonete.dados;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import lanchonete.modelo.Pedido;

public class PedidoDados implements Serializable {
    
     public void cadastrarPedido(Pedido objPedido){
     ArrayList<Pedido> listPedido = new ArrayList<>();
        try{
            listPedido = listarPedido();
        }catch(FileNotFoundException e){ 
            e.getMessage();
            System.out.println("Criando arquivo... ");
            File arquivo = new File("pedido.ser");
            try{     
                arquivo.createNewFile(); 
            }catch(IOException x){ 
                x.getMessage();
            }
        }catch(ClassNotFoundException | IOException e){
            e.getMessage();
        }
        try{
           listPedido.add(objPedido);
           File endereco = new File("pedido.ser");
           FileOutputStream fluxo = new FileOutputStream(endereco);
           ObjectOutputStream oos = new ObjectOutputStream(fluxo);
           oos.writeObject(listPedido);
           oos.flush();
           fluxo.flush();
           oos.close();
           fluxo.close();        
        }catch(IOException e){
           e.getMessage();
        }
    }
    
    public ArrayList<Pedido> listarPedido() throws FileNotFoundException, IOException, ClassNotFoundException{
        ArrayList<Pedido> listPedido;
        File endereco = new File("pedido.ser");
        FileInputStream fluxo = new FileInputStream(endereco);
        ObjectInputStream lerObj = new ObjectInputStream(fluxo);
        listPedido = (ArrayList<Pedido>) lerObj.readObject();
     return listPedido;
    }
    
    public Pedido pesquisaPedido(int cod) throws IOException, FileNotFoundException, ClassNotFoundException{
        Pedido resultado = new Pedido();
        ArrayList <Pedido> listPedido = listarPedido();
        for(Pedido p : listPedido){
            if(p.getCodigo() == cod){
                resultado = p;
                break;
            }
        }
    return resultado;
    }
    
    /**
     *
     * @param cod
     * @throws FileNotFoundException
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public void removerPedido(int cod) throws FileNotFoundException, IOException, ClassNotFoundException{
        ArrayList <Pedido> listPedido = listarPedido();
        for(int i = 0; i<listPedido.size(); i++){
            if(listPedido.get(i).getCodigo() == cod){
                listPedido.remove(listPedido.get(i));
            }
        }
        File endereco = new File("pedido.ser");
        FileOutputStream fluxo = new FileOutputStream(endereco);
        try(ObjectOutputStream gravarObj = new ObjectOutputStream(fluxo)){
            gravarObj.writeObject(listPedido);
        }
    }
}
