package lanchonete.controle;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import lanchonete.modelo.Gerente;

public class ControleGerente {

    ArrayList<Gerente> listGerente = new ArrayList<>();

    /*
     public void cadastrarGerente(String nome, String telefone, String senha,String sexo, String cpf) throws IOException, FileNotFoundException, ClassNotFoundException{
        Gerente objGerente = new Gerente(nome, telefone, senha, sexo, cpf);
        listGerente.add(objGerente);
        //   objGerente.cadastrarGerente(objGerente);
    }
    
    public String listarArquivoGerente() throws IOException, FileNotFoundException, ClassNotFoundException{
      String arqList = "";
        ArrayList <Gerente > listRetorno = objGerente.listaArqGerente();
        for(int i = 0; i<listRetorno.size(); i++){
            arqList = "\nNome : "+listRetorno.get(i).getNome()+
                      "\nCPF: "+listRetorno.get(i).getCpf();
        } 
        return arqList;
    }
    
    public String pesquisarGerente(String cod) throws IOException, FileNotFoundException, ClassNotFoundException{
     Gerente retornoPesq  = objGerente.pesquisaGerente(cod);
     return "Nome: "+retornoPesq.getNome()+
             "\nCPF: "+retornoPesq.getCpf();
    }
    public void removerGerente(String cod) throws IOException, FileNotFoundException, ClassNotFoundException{
        objGerente.removerGerente(cod);
    }
    
    public Gerente pesquisarGerenteList(String nome){
        for(Gerente g : listGerente){
            if(g.getNome().equals(nome)){
                return g;
            }
        }
        return null;
    }
     */
    public void cadastrarGerente(String nome, String telefone, String senha, String sexo, String cpf) throws IOException, FileNotFoundException, ClassNotFoundException {
        
        Gerente g = new Gerente(nome, telefone, senha, sexo, cpf);
        g.cadastrarGerente(g);
    }

    public Gerente pesquisarGerente(String nome) throws IOException, FileNotFoundException, ClassNotFoundException {
        ArrayList<Gerente> listGerente = listarGerente();
        for (Gerente g : listGerente) {
            if (nome.equals(g.getNome())) {
               
                return g;
            }
        }
        return null;
    }
    public ArrayList<Gerente> listarGerente() throws IOException, FileNotFoundException, ClassNotFoundException{
        Gerente g = new Gerente();
        return g.listarGerente();
    }
    public void removerGerente(String nome) throws IOException, FileNotFoundException, ClassNotFoundException{
        Gerente g = this.pesquisarGerente(nome);
        g.removerGerente(g);
    }
    public boolean loginGerente(String nome, String senha) throws IOException, FileNotFoundException, ClassNotFoundException {
        Gerente retornoPesq = pesquisarGerente(nome);
        if (retornoPesq.getSenha().equals(senha)) {
            return true;
        } else {
            return false;
        }
    }
}
