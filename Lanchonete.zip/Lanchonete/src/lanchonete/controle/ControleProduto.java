package lanchonete.controle;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import lanchonete.modelo.Produto;

public class ControleProduto {

     ArrayList<Produto> listProduto = new ArrayList<>();

    public void cadastrarProduto(String nome, double valor, String descricao) {
        Produto g = new Produto(nome, valor, descricao);
        g.cadastrarProduto(g);
    }
    public Produto pesquisarProduto(int id) throws IOException, FileNotFoundException, ClassNotFoundException {
        ArrayList<Produto> listProduto = listarProduto();
        for(Produto g : listProduto){
            if((id == g.getId())){
                return g;
            }
        }
        return null;
    }
    public ArrayList<Produto> listarProduto() throws IOException, FileNotFoundException, ClassNotFoundException{
        Produto g = new Produto();
        return g.listarProduto();
    }
    public String listarCardapio() throws IOException, FileNotFoundException, ClassNotFoundException{
        String cardapio = "";
        ArrayList<Produto> listProduto = listarProduto();
        for(int i =0; i<listProduto.size(); i++){
            cardapio += "\n----------------------------------------------------------"+
                        "\n"+listProduto.get(i).getNome()+" - Codigo: "+listProduto.get(i).getId()+
                        "\n"+listProduto.get(i).getDescricao()+" - R$ "+listProduto.get(i).getValor()+
                        "\n----------------------------------------------------------";
        }
        return cardapio;
    
    }
    public void removerGerente(int id) throws IOException, FileNotFoundException, ClassNotFoundException{
        Produto g = this.pesquisarProduto(id);
        g.removerProduto(g);
    }
    /*
     public String listarArquivoProduto() throws IOException, FileNotFoundException, ClassNotFoundException {
        String arqList = "";
        ArrayList<Produto> listRetorno = objProduto.listaArqProduto();
        for (int i = 0; i < listRetorno.size(); i++) {
            arqList = "Nome: " + listRetorno.get(i).getNome() + " id = " + listRetorno.get(i).getId()
                    + "\nValor: " + listRetorno.get(i).getValor()
                    + "\nDescrição: " + listRetorno.get(i).getDescricao();
        }
        return arqList;
    }
    public Produto pesquisarProdPedido(int id) throws IOException, FileNotFoundException, ClassNotFoundException {
        Produto retornoPesq = objProduto.pesquisaProduto(id);

        return retornoPesq;
    }

    public void removerProduto(int cod) throws IOException, FileNotFoundException, ClassNotFoundException {
        objProduto.removerProduto(cod);
    }
    */


}
