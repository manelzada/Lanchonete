
package lanchonete.controle;

import lanchonete.modelo.Pedido;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import lanchonete.modelo.Produto;

public class ControlePedido {
    
    Pedido objPedido = new Pedido();
    public Pedido cadastrarPedido(ArrayList<Produto>listPedido, int codigo, String usuario) throws IOException{
        Pedido objPedido = new Pedido(listPedido,codigo,usuario);
        objPedido.cadastrarPedido(objPedido);
    return objPedido;
    }
    public String listarArquivoPedido() throws IOException, FileNotFoundException, ClassNotFoundException{
        String arqList="";
         ArrayList <Pedido> listRetorno = objPedido.listarPedido();
         for(int  i = 0; i<listRetorno.size(); i++){
            //arqList =???
         }
    return arqList;
    }
    
    public String pesquisarPedido(int cod) throws IOException, FileNotFoundException, ClassNotFoundException{
        Pedido retornoPesq = objPedido.pesquisaPedido(cod);
        
        return"\n-------------------------------------"+ 
              "\nProduto: "+retornoPesq.getUsuario()+
              "\nCódigo: "+retornoPesq.getCodigo()+
              "\n-----------------------------------";
    }
    public void removerPedido(int cod) throws IOException, FileNotFoundException, ClassNotFoundException{
        objPedido.removerPedido(cod);
    }
    
}
