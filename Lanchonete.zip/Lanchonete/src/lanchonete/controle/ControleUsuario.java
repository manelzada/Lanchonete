package lanchonete.controle;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import lanchonete.modelo.Usuario;

public class ControleUsuario {

   
     Usuario objUsuario = new Usuario();
    public void cadastrarUsuario(String nome, String nickName, String email, String telefone, String cpf, String senha, String sexo){
        Usuario objUsuario = new Usuario(nome, nickName, email, telefone, cpf, senha, sexo);
        objUsuario.cadastrarUsuario(objUsuario);
    }
    
    public String listarArquivoUsuario() throws IOException, FileNotFoundException, ClassNotFoundException{
      String arqList = "";
        ArrayList <Usuario > listRetorno = objUsuario.listaArqUsuario();
        for(int i = 0; i<listRetorno.size(); i++){
            arqList +="Nome: "+listRetorno.get(i).getNome()+
                        "\n Cpf: "+listRetorno.get(i).getCpf()+"\n";
        } 
        return arqList;
    }
    
    public String pesquisarUsuario(String nickName) throws IOException, FileNotFoundException, ClassNotFoundException{
     Usuario retornoPesq  = objUsuario.pesquisaUsuario(nickName);
     return "Nome: "+retornoPesq.getNome()+
             "\n Cpf: "+retornoPesq.getCpf();
    }
    public void removerUsuario(String cod) throws IOException, FileNotFoundException, ClassNotFoundException{
        objUsuario.removerUsuario(cod);
    }
    
    public boolean loginUsuario(String nickName, String senha) throws IOException, FileNotFoundException, ClassNotFoundException{
        
        Usuario retornoPesq  = objUsuario.pesquisaUsuario(nickName);
        if(retornoPesq.getSenha().equals(senha)){
            return true;
        }else{
            return false;   
        }
    }
    
    
}


