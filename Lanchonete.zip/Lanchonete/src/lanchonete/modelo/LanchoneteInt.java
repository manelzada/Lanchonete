package lanchonete.modelo;

import java.util.ArrayList;

public interface LanchoneteInt {

    public ArrayList<Produto> getProduto();
    
    public void setProduto(ArrayList<Produto> produto);

    public int getCodigo();

    public void setCodigo(int codigo);
}
