
package lanchonete.modelo;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import lanchonete.dados.PedidoDados;


public class Pedido implements Serializable, LanchoneteInt{

    private int codigo;
    private ArrayList<Produto> listPedido;
    private String usuario;

    public Pedido(ArrayList<Produto>listPedido, int codigo, String usuario) {
        this.codigo = codigo;
        this.listPedido = listPedido;
        this.usuario = usuario;
    }
    public String getUsuario() {
        return usuario;
    }

    public ArrayList<Produto> getListPedido() {
        return listPedido;
    }

    public void setListPedido(ArrayList<Produto> listPedido) {
        this.listPedido = listPedido;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
    
    public Pedido(){}

    @Override
    public int getCodigo() {
        return codigo;
    }
    @Override
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
   
    @Override
    public ArrayList<Produto> getProduto() {
        return this.getListPedido();
    }

    @Override
    public void setProduto(ArrayList<Produto> produto) {
        setListPedido(listPedido);
    }
    
    public void cadastrarPedido(Pedido objPedido) throws IOException{
        PedidoDados oD = new PedidoDados();
        oD.cadastrarPedido(objPedido);
    }
    
    public Pedido pesquisaPedido(int cod) throws IOException, FileNotFoundException, ClassNotFoundException{
        PedidoDados oD = new PedidoDados();
        Pedido retorno = oD.pesquisaPedido(cod);
        return retorno;
    }
    
    public ArrayList<Pedido> listarPedido() throws IOException, FileNotFoundException, ClassNotFoundException{
        PedidoDados oD = new PedidoDados();
        ArrayList <Pedido> retorno = oD.listarPedido();
        return retorno;
    }
    
    public void removerPedido(int cod) throws IOException, FileNotFoundException, ClassNotFoundException{
       PedidoDados oD = new PedidoDados();
        oD.removerPedido(cod);
    }
    
    public double calcTotal(Pedido objPedido){
        ArrayList<Produto> listProduto = objPedido.getListPedido();
        double total = 0;
        for(int i= 0; i<listProduto.size(); i++){
            total += listProduto.get(i).getValor();
        }
        return total;
        
    }
    
    public String imprimirPedido(Pedido objPedido){
        double total = calcTotal(objPedido);
        String listPedidostr="";
        for(int i = 0; i<getListPedido().size(); i++){
           listPedidostr += "\nNome:"+getListPedido().get(i).getNome()+
                            "\nvalor:"+getListPedido().get(i).getValor();
        }
        
        return"Pedido"+
              "Nome cliente:"+getUsuario()+  
              "\nLanches pedidos:"+
              "\n"+listPedidostr+
              "\n------------------- "+
              "\nTOTAL = " + calcTotal(objPedido) + "\n";           
    }
    
}
