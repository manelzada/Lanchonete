package lanchonete.modelo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;
import lanchonete.dados.ProdutoDados;

public class Produto implements Serializable {
    private static int contador = 1;
    private String nome;
    private double valor;
    private int id;
    private String descricao;

    public Produto(String nome, double valor, String descricao) {
        this.nome = nome;
        this.valor = valor;
        this.descricao = descricao;
        this.contador = lerArquivo();
        this.id = contador;
        contador++;
        escreverArquivo();
    }

    
    public Produto() {}

    public void cadastrarProduto(Produto p) {
        ProdutoDados pd = new ProdutoDados();
        pd.cadastrarProduto(p);
    }

    public ArrayList<Produto> listarProduto() throws IOException, FileNotFoundException, ClassNotFoundException {
        ProdutoDados pd = new ProdutoDados();
        return pd.listarProduto();
    }

    public void removerProduto(Produto p) throws IOException, FileNotFoundException, ClassNotFoundException {
        ProdutoDados pd = new ProdutoDados();
        pd.removerProduto(p);
    }
    private static int lerArquivo(){
    //string antes "/src/arquivo/id.txt" string depois "src/arquivo/id.txt"
    File arquivo = new File("D:\\Documentos\\NetBeansProjects\\Lanchonete\\id.txt");//instancia um objeto do tipo File com o diretorio passado por string
    try{
      Scanner leitor = new Scanner(arquivo);//instancia um objeto scanner passando o arquivo como parametro
      String id = leitor.next();//lê os caracteres até antes de encontrar um espaço e armazena na String id
      leitor.close();//fecha o Scanner
      return Integer.parseInt(id);//transforma a String id em um inteiro e retorna
    }
    catch(FileNotFoundException e){
      e.printStackTrace();
      return 0;
    }
  }

  private static void escreverArquivo(){
    try {
      FileWriter escritor = new FileWriter("D:\\Documentos\\NetBeansProjects\\Lanchonete\\id.txt");//instacia um objeto do tipo FileWriter com o diretorio passado por string
      //é preciso converter para string antes de salvar
      //pois estamos salvando caracteres
      String contadorString = String.valueOf(contador);//converte o inteiro contador em String
      escritor.write(contadorString);//escreve a String no arquivo, sobreescrevendo o que está nele
      escritor.close();//fecha o FileWriter
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

}
