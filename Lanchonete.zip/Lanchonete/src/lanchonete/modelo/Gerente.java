package lanchonete.modelo;

import lanchonete.dados.GerenteDados;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

public class Gerente implements Serializable {

    private String nome;
    private String telefone;
    private String sexo;
    private String senha;
    private String cpf;

    public Gerente() {
    }

    public Gerente(String nome, String telefone, String senha, String sexo, String cpf) {
        this.nome = nome;
        this.telefone = telefone;
        this.senha = senha;
        this.sexo = sexo;
        this.cpf = cpf;
    }

    public void cadastrarGerente(Gerente g) throws IOException, FileNotFoundException, ClassNotFoundException {
        
        GerenteDados gd = new GerenteDados();
        gd.cadastrarGerente(g);

    }

    public ArrayList<Gerente> listarGerente() throws IOException, FileNotFoundException, ClassNotFoundException {
        GerenteDados gd = new GerenteDados();
        return gd.listarGerente();

    }

    public void removerGerente(Gerente g) throws IOException, FileNotFoundException, ClassNotFoundException {
        GerenteDados gd = new GerenteDados();
        gd.removerGerente(g);
    }

   
    public String imprimirGerente() {
        return "Nome: " + this.nome
                + "senha: " + this.senha
                + "sexo: " + this.sexo
                + "telefone: " + this.telefone
                + "cpf:" + this.cpf;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}
