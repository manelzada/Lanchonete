package lanchonete.modelo;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import lanchonete.dados.UsuarioDados;

public class Usuario implements Serializable {

    private String nome, nickName, email, telefone, cpf, senha, sexo;
    UsuarioDados objUsuarioD = new UsuarioDados();
    public Usuario(String nome, String nickName, String email, String telefone, String cpf, String senha, String sexo) {
        this.nome = nome;
        this.nickName = nickName;
        this.email = email;
        this.telefone = telefone;
        this.cpf = cpf;
        this.senha = senha;
        this.sexo = sexo;
    }
    
        public Usuario(){}

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
    public void cadastrarUsuario(Usuario objUsuario){
        objUsuarioD.cadastrarUsuarioD(this);
    }
    public Usuario pesquisaUsuario(String NickName) throws IOException, FileNotFoundException, ClassNotFoundException{
        UsuarioDados userD = new UsuarioDados();
        Usuario retorno = userD.pesquisaUsuario(NickName);
        return retorno;
    }
    public ArrayList<Usuario> listaArqUsuario() throws IOException, FileNotFoundException, ClassNotFoundException{
      ArrayList <Usuario> retorno = objUsuarioD.listarUsuarios();
      return retorno;
    }
    public void removerUsuario(String cod) throws IOException, FileNotFoundException, ClassNotFoundException{
        objUsuarioD.removerUsuario(cod);
    }
    
}
