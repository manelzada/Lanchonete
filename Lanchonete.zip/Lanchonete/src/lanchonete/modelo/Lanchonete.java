
package lanchonete.modelo;

import java.util.ArrayList;

public abstract class Lanchonete {
    private ArrayList<Produto> produto;
    private int codigo;

    public Lanchonete(ArrayList<Produto> produto, int codigo) {
        this.produto = produto;
        this.codigo = codigo;
    }

    public ArrayList<Produto> getProduto() {
        return produto;
    }
    public void setProduto(ArrayList<Produto> produto) {
        this.produto = produto;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

 
    
}
